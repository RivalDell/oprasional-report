

<?php $__env->startSection('title', 'Manajemen Data Outlet'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-danger mb-0">Manajemen Data Outlet</h3>
        <small class="text-muted">Kelola data outlet, target operasional, dan daftar crew</small>
    </div>
    <a href="<?php echo e(route('outlets.create')); ?>" class="btn btn-danger">+ Tambah Outlet Baru</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nama Outlet</th>
                        <th>Target Sales / Hari</th>
                        <th>Target Transaksi</th>
                        <th>Jumlah Crew</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($outlets->currentPage() - 1) * $outlets->perPage()); ?></td>
                            <td class="fw-bold"><?php echo e($outlet->name); ?></td>
                            <td class="text-success fw-bold">Rp <?php echo e(number_format($outlet->target_sales, 0, ',', '.')); ?></td>
                            <td><?php echo e(number_format($outlet->target_transactions)); ?> Transaksi</td>
                            <td><span class="badge bg-info text-dark"><?php echo e($outlet->employees_count); ?> Orang</span></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('outlets.edit', $outlet->id)); ?>" class="btn btn-sm btn-outline-warning">Edit & Crew</a>
                                <form action="<?php echo e(route('outlets.destroy', $outlet->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus outlet ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">Belum ada data outlet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="d-flex justify-content-end mt-3">
    <?php echo e($outlets->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\momoyo-report\resources\views/outlets/index.blade.php ENDPATH**/ ?>