

<?php $__env->startSection('title', 'Manajemen User'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-danger mb-0">Manajemen User Pengguna</h3>
        <small class="text-muted">Kelola akun, hak akses role, dan penugasan outlet</small>
    </div>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-danger">+ Tambah User Baru</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nama Pengguna</th>
                        <th>Email</th>
                        <th>Role Akses</th>
                        <th>Outlet Penugasan</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($users->currentPage() - 1) * $users->perPage()); ?></td>
                            <td class="fw-bold"><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td>
                                <?php if($u->role === 'superadmin'): ?>
                                    <span class="badge bg-danger">Superadmin</span>
                                <?php elseif($u->role === 'atasan'): ?>
                                    <span class="badge bg-primary">Atasan / Management</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Staff Operasional</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($u->outlet): ?>
                                    <span class="badge bg-info text-dark"><?php echo e($u->outlet->name); ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">Semua Outlet / Pusat</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('users.edit', $u->id)); ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                                
                                <?php if(auth()->id() !== $u->id): ?>
                                    <form action="<?php echo e(route('users.destroy', $u->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus user ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">Belum ada data user pengguna.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="d-flex justify-content-end mt-3">
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\momoyo-report\resources\views/users/index.blade.php ENDPATH**/ ?>