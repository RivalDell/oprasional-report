

<?php $__env->startSection('title', 'Daftar Laporan Operasional - Momoyo'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-danger mb-0">Daftar Laporan Operasional Harian</h3>
        <small class="text-muted">Momoyo Operational Management System</small>
    </div>
    
    <?php if(auth()->user()->role === 'superadmin'): ?>
        <a href="<?php echo e(route('reports.create')); ?>" class="btn btn-danger">+ Buat Laporan Baru</a>
    <?php endif; ?>
</div>

<!-- Notifikasi Sukses -->
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Form Filter & Pencarian -->
<div class="card mb-4 shadow-sm border-0">
    <div class="card-body">
        <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label fw-bold">Outlet</label>
                <select name="outlet_id" class="form-select">
                    <option value="">-- Semua Outlet --</option>
                    <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($outlet->id); ?>" <?php echo e(request('outlet_id') == $outlet->id ? 'selected' : ''); ?>>
                            <?php echo e($outlet->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold">Sampai Tanggal</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-bold">Shift</label>
                <select name="shift" class="form-select">
                    <option value="">-- Semua Shift --</option>
                    <option value="Opening" <?php echo e(request('shift') == 'Opening' ? 'selected' : ''); ?>>Opening</option>
                    <option value="Middle" <?php echo e(request('shift') == 'Middle' ? 'selected' : ''); ?>>Middle</option>
                    <option value="Closing" <?php echo e(request('shift') == 'Closing' ? 'selected' : ''); ?>>Closing</option>
                </select>
            </div>
            <div class="col-md-1 d-flex align-items-end gap-1">
                <button type="submit" class="btn btn-primary w-100">Cari</button>
                <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-outline-secondary" title="Reset">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Tabel Data Laporan -->
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Tanggal</th>
                        <th>Outlet</th>
                        <th>Shift</th>
                        <th>Actual Sales</th>
                        <th>Rating</th>
                        <th>Dibuat Oleh</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($reports->currentPage() - 1) * $reports->perPage()); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($report->report_date)->format('d-m-Y')); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($report->outlet->name ?? 'N/A'); ?></span></td>
                            <td><?php echo e($report->shift); ?></td>
                            <td class="fw-bold text-success">
                                Rp <?php echo e(number_format($report->sales_finance['actual_sales'] ?? 0, 0, ',', '.')); ?>

                            </td>
                            <td>
                                <?php if($report->performance_rating === 'Excellent'): ?>
                                    <span class="badge bg-success">Excellent</span>
                                <?php elseif($report->performance_rating === 'Good'): ?>
                                    <span class="badge bg-info text-dark">Good</span>
                                <?php elseif($report->performance_rating === 'Average'): ?>
                                    <span class="badge bg-warning text-dark">Average</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Below Target</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($report->prepared_by); ?></td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('reports.show', $report->id)); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                                    <a href="<?php echo e(route('reports.export-pdf', $report->id)); ?>" class="btn btn-sm btn-outline-success">PDF</a>

                                    <?php if(auth()->user()->role === 'superadmin'): ?>
                                        <a href="<?php echo e(route('reports.edit', $report->id)); ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                                        <form action="<?php echo e(route('reports.destroy', $report->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus laporan ini?');" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">Belum ada laporan operasional yang ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
<div class="d-flex justify-content-end mt-3">
    <?php echo e($reports->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\momoyo-report\resources\views/reports/index.blade.php ENDPATH**/ ?>